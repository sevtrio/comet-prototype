//@application start
 function main(myApp){
  //@your app code
  
  
  //@use jquery library
  
  
  //@use sevtrio framework
  
  
  //@update DOM using plain html save under tpl folder
  
  
  //@myApp.UI.Control('tpl/main.tpl',[css-selector]'); 
  myApp.UI.Control('tpl/notification.tpl','.notification');
  
  
  //@on tpl files use events to pass the elem to function since the DOM is virtual
  myApp.UI.Control('tpl/footer.tpl','.footer');
  
  
  //@bootstrap is ready so you can start working on your content
  
  
  //@Loaders pre-configured
  
  
  //@init branding
  comet.assets.logo();
 }

