/*
Goodwish.Matyila - Developer of sevtrio.js
2016 RSA, Creative Commons, BDGROUP Mobile and Technology solutions
@Application
Render.UI.Component - Ajax tpl loading
Render.UI.Create - Renders new elements to DOM
*/

'use strict';
 //namespace global Application
 var Application = Application || {};
     Application.UI = {};
//Component render
Application.UI.Component = (function(path,context){
 var xhr = new XMLHttpRequest();
 xhr.open("GET", path);
 xhr.addEventListener('readystatechange',function(){
  if(xhr.status == 200){
   document.querySelector(context).innerHTML = xhr.responseText;
   }
 });
 xhr.send();
});

//create new elements in DOM
Application.UI.Create = (function(rootObject, Obj_sender, sp_Constr,objIdef){ 
    (function(){
     var renderView = document.createElement(rootObject);
     renderView.id = objIdef;
      Obj_sender.apply(renderView);
    document.querySelector(sp_Constr).appendChild(renderView);
   }());
});

Application.UI.Preloader = "<center><em>please wait...</em></center>";

//instatiate component render
Application.UI.Control = (function(Sender,idx){
 document.querySelector(idx).innerHTML = Application.UI.Preloader;
 setTimeout(function(){
   Application.UI.Component(Sender,idx);
   //Render component to layer
   },3000)
});

Application.RC = (function(path,context){
 var xhr = new XMLHttpRequest();
 xhr.open("GET", path);
 xhr.addEventListener('readystatechange',function(){
  if(xhr.status == 200){
   return xhr.responseText;
   }
 });
 xhr.send();
});

