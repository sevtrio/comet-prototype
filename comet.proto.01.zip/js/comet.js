/*
* Sevtrio @Deploy App
* Goodwish Matyila
* goomatyila@gmail.com
* Comet config file
* #assets  #config   #cloud   #lib   #distribution
*/
var comet = comet || {

 //@assets manager
 assets:{
  logo:(function(){
   Application.UI.Control('tpl/logo.tpl','.logo');
  })
 },
 
 //@group conf
 config:{
  application: 'sevtrio',
  description: 'prototyping light-comet',
  version: '1.0',
  year: '2016'
 },
 
 //@workspace
 cloud:{
   boot:(function(){
   Application.UI.Preloader =["<img src='assets/img/cube.gif' width='26'/>"];
    Application.UI.Control('tpl/main.tpl','.comet-main');
   }),
   framework:require(['sevtrio','jquery.min','comet'],function(){ 
     comet.cloud.boot();
     Application.UI.Preloader =["<img src='assets/img/cube.gif' width='26'/>"];
     return main(Application);
   })
  },
  
  //@extras
  lib:{
   render:[]
  },
  
  //@dist
  distribution:{
   templ:'/tpl/main.tpl'
  }
  
}


