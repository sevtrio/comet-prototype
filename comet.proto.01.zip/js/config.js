//@Config
require(['main','comet'],function(){
 comet.cloud.app.framework;
//@startup comet

//@client config
 
//@app details
 comet.config.application =''; //set your app name
 comet.config.version =''; //set app version
 comet.config.description =''; //set app descr
 comet.config.year =''; //set app release

});